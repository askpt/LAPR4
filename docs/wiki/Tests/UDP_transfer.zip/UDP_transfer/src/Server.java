import java.io.IOException;
import java.net.*;

public class Server implements Runnable {
    private static Server instance = null;
    private int port;

    private Server() {
    }

    public static Server getInstance() {
	if (instance == null) {
	    instance = new Server();
	}
	return instance;
    }

    public void findClients(int port) throws IOException {
	this.port = port;
	Thread thr = new Thread(getInstance());
	thr.start();
    }

    @Override
    public void run() {
	try {
	    DatagramSocket serverSocket;
	    serverSocket = new DatagramSocket(9876);

	    byte[] receiveData = new byte[1024];
	    byte[] sendData = new byte[1024];
	    int i = 1;
	    while (i > 0) {
		DatagramPacket receivePacket = new DatagramPacket(receiveData,
			receiveData.length);

		serverSocket.receive(receivePacket);
		String testReceive = new String(receivePacket.getData());
		testReceive = Validate.removeMessage(testReceive);

		if (testReceive.equals("send me connection")) {
		    InetAddress IPAddress = receivePacket.getAddress();
		    int portPacket = receivePacket.getPort();

		    int portSend = port;

		    String portConnect = portSend + "";
		    int portLenght = portConnect.length();
		    portConnect = portLenght + "-" + portSend;

		    sendData = portConnect.getBytes();
		    DatagramPacket sendPacket = new DatagramPacket(sendData,
			    sendData.length, IPAddress, portPacket);
		    serverSocket.send(sendPacket);
		}
	    }
	    // serverSocket.close();

	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

    }
}
