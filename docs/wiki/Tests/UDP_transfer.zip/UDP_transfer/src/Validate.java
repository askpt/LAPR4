public class Validate {

    public static String removeMessage(String message) {
	String tmp = "";
	int lenght = 0, i = 0;

	while (message.charAt(i) != '-') {
	    tmp = tmp + message.charAt(i);
	    i++;
	}
	i++;
	lenght = Integer.parseInt(tmp);
	lenght += i;
	tmp = "";

	for (; i < lenght; i++) {
	    tmp = tmp + message.charAt(i);
	}

	return tmp;
    }

}
