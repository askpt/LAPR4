import java.net.InetAddress;

public class Connections {

    private final int port;
    private final InetAddress IP;

    public Connections(int port, InetAddress inetAddress) {
	this.port = port;
	this.IP = inetAddress;
    }

    public InetAddress getIP() {
	return IP;
    }

    public int getPort() {
	return port;
    }

    @Override
    public String toString() {
	return "IP= " + IP + ":" + port;
    }

    @Override
    public boolean equals(Object obj) {
	if (obj instanceof Connections) {
	    return (IP.equals(((Connections) obj).IP) && (port == ((Connections) obj).port));
	}
	return false;
    }
}
