import java.io.IOException;
import java.util.*;

public class Main {

    /**
     * @param args
     */

    static Scanner in = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
	Scanner in = new Scanner(System.in);
	int port = in.nextInt();
	Server.getInstance().findClients(port);
	List<Connections> con = Client.getInstance().startClient();
	System.out.println(con);
    }
}
