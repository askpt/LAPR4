import java.io.IOException;
import java.net.*;
import java.util.*;

public class Client implements Runnable {

    List<Connections> connections;
    private static Client instance;

    private Client() {
    }

    public static Client getInstance() {
	if (instance == null) {
	    instance = new Client();
	}
	return instance;
    }

    public List<Connections> startClient() throws IOException {
	try {
	    Thread thr = new Thread(getInstance());
	    thr.start();
	    thr.join();
	} catch (InterruptedException e) {
	}
	return connections;
    }

    @Override
    public void run() {
	try {
	    DatagramSocket clientSocket;
	    clientSocket = new DatagramSocket();
	    clientSocket.setBroadcast(true);
	    InetAddress IPAddress = InetAddress.getByName("255.255.255.255");
	    connections = new ArrayList<Connections>();
	    byte[] sendData = new byte[1024];
	    byte[] receiveData = new byte[1024];
	    int i = 2;
	    while (i > 0) {
		String sentence = "18-send me connection";
		sendData = sentence.getBytes();
		DatagramPacket sendPacket = new DatagramPacket(sendData,
			sentence.length(), IPAddress, 9876);
		clientSocket.send(sendPacket);
		DatagramPacket receivePacket = new DatagramPacket(receiveData,
			receiveData.length);
		clientSocket.receive(receivePacket);
		String modifiedSentence = new String(receivePacket.getData());
		modifiedSentence = Validate.removeMessage(modifiedSentence);
		int port = Integer.parseInt(modifiedSentence);
		Connections con = new Connections(port,
			receivePacket.getAddress());
		if (!connections.contains(con)) {
		    connections.add(con);
		}
		i--;
	    }
	    clientSocket.close();
	} catch (IOException e) {
	}

    }
}
