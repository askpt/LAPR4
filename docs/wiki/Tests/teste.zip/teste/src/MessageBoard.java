import java.util.*;

public class MessageBoard extends Observable {
	private String message;

	public String getMessage() {
		return message;
	}

	public void changeMessage(String message, Test tst) {
		this.message = message;
		setChanged();
		notifyObservers(tst);
		clearChanged();
	}

	public static void main(String[] args) {
		MessageBoard board = new MessageBoard();
		Student bob = new Student();
		board.addObserver(bob);
		Test tst = new Test("a2", "a3", 0);
		board.changeMessage("More Homework!", tst);
		System.out.println(tst.getChoosed());
	}
}

class Student implements Observer {
	static Scanner in = new Scanner(System.in);

	@Override
	public void update(Observable o, Object arg) {
		System.out.println("App: " + ((Test) arg).getApp() + "\ndb:"
				+ ((Test) arg).getDb());
		int choose = in.nextInt();
		if (choose == 1) {
			((Test) arg).setChoosed(1);
		} else if (choose == 2) {
			((Test) arg).setChoosed(1);
		}
	}
}

class Test {

	public Test(String app, String db, int choosed) {
		this.app = app;
		this.db = db;
		this.choosed = choosed;
	}

	private final String app;
	private final String db;
	private int choosed;

	public String getApp() {
		return app;
	}

	public int getChoosed() {
		return choosed;
	}

	public String getDb() {
		return db;
	}

	public void setChoosed(int choosed) {
		this.choosed = choosed;
	}
}
