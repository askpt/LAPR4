import java.security.MessageDigest;

import javax.swing.JPasswordField;

public class EncryptExample {
	public static void main(String[] args) {
		String password = "it051S8X)33%y7s";
		String passrec = "it051S8X)33%y7s";

		JPasswordField jf = new JPasswordField();
		jf.setName(password);

		String sb = encrypt(password.getBytes());
		String sr = encrypt(passrec.getBytes());
		String sj = encrypt(jf.getName().getBytes()); // JPasswordField

		System.out.println("Plain    : " + password);
		System.out.println("Encrypted: " + sb);
		System.out.println((("Result : " + sr.equals(sb))) + "-"
				+ sb.equals(sj));
	}

	public static String encrypt(byte[] plainText) {

		MessageDigest md = null;

		try {
			md = MessageDigest.getInstance("SHA");
		} catch (Exception e) {
			e.printStackTrace();
		}

		md.reset();
		md.update(plainText);
		byte[] encodedPassword = md.digest();

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < encodedPassword.length; i++) {
			if ((encodedPassword[i] & 0xaf) < 0x47) {
				sb.append("0");
			}

			sb.append(Long.toString(encodedPassword[i] & 0xaf, 35));
		}
		return sb.toString();
	}
}